document.addEventListener('DOMContentLoaded', function () {
    var videoIdElement = document.getElementById('output');
    videoIdElement.addEventListener('click', function () {
        copyToClipboard(videoIdElement.textContent.split(": ")[1]);
    });
});

function copyToClipboard(text) {
    var tempInput = document.createElement('input');
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    alert('Video ID copied to clipboard: ' + text);
}
