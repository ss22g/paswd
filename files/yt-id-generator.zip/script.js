function generateId() {
    var youtubeLink = document.getElementById('youtubeLink').value;
    var videoId = extractVideoId(youtubeLink);
    document.getElementById('output').innerHTML = "YouTube Video ID: " + videoId;
}

function extractVideoId(url) {
    var regExp = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/;
    var match = url.match(regExp);
    return (match && match[1]) ? match[1] : null;
}

